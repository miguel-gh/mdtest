# Información de utilidad #

Esta sección contiene información de utilidad para cualquier participante
del equipo, sobretodo personas que se están integrando al mismo.

## Con quién debo hablar ##

* Levanta tus preocupaciones con el equipo en la daily.
* Únete al canal de slack del team ***Habitat - TINET***
    (`habitat-tinet.slack.com`).
* Si tienes dudas, conversa con el líder técnico de tu equipo
    o con el arquitecto del proyecto.

## Equipos de trabajo ##

Los siguientes son los integrantes de los equipos que trabajan
en el proyecto Nueva Web.

### Equipo Saiyajines Furiosos (afphabitat.nueva-web-sf@tinet.cl) ###

* Jorge Avalos (javalos@tinet.cl). Scrum Master.
* Vanessa Vidal (vanessa.vidal@tinet.cl).
* Andrés Osorio (andres.osorio@tinet.cl).
* Angélica Figueroa (angelica.figueroar@gmail.com).
* Cristoffer Morales (cmorales@tinet.cl).
* Fabián Urra (fabian.urra@tinet.cl).
* Franco Castro (franco.castro@tinet.cl).

### Equipo 40tena (afphabitat.nueva-web-40tena@tinet.cl) ###

* Daniel Muñoz (daniel.munoz@tinet.cl). Scrum Master.
* Bastian Mella (bastian.mella@tinet.cl).
* Jesús Vargas (jesus.vargas@tinet.cl).
* Patricio Muller (pmuller@afphabitat.cl).
* Roxana Carrera (roxana.carrera@tinet.cl).
* Sebastián Muñoz (sebastian.munoz@tinet.cl).
* Sebastián Macheo (sebastian.macheo@tinet.cl).

### Equipo Fenix (afphabitat.nueva-web-fenix@tinet.cl) ###

* Mauricio Morales (mauricio.morales@tinet.cl). Scrum Master.
* Felix Atria (fatriac@afphabitat.cl).
* José Llopis (jose.llopis@tinet.cl).
* Andrés Arce (andres.arce@tinet.cl).
* Angel Absé (angel.abse@tinet.cl).
* Oscar Echeverria (oscar.echeverria@tinet.cl).

### Equipo Diseño (afphabitat.nueva-web-diseno@tinet.cl) ###

* Victor Roman (victor.roman@tinet.cl).
* Rebeca Lobos (rebeca.lobos@tinet.cl).
* Francisco Campos (francisco.campos@tinet.cl).

### Equipo Transversal ###

* Michael Stone (mstonec@afphabitat.cl). Product Owner.
* Roberto San Martín (rsanmartin@tinet.cl). Arquitecto TINET.
* Claudio Gonzalez (cgonzalp@afphabitat.cl). Arquitecto AFP Habitat.

## Utilidades para ambiente local ##

Los siguientes archivos de configuración ayudarán en la configuración de
su ambiente local.

* Configuración Maven ([~/.m2/settings.xml](config/java/maven/m2_settings.xml)).
  Esta configuración es necesaria para poder realizar la construcción
  de los componentes java que se desarrollarán en el proyecto.

* Configuración HOST ([/etc/hosts](config/os/etc_hosts)). Este
  archivo ***NO DEBE SER REEMPLAZADO*** sino que su contenido debe ser editado
  de forma manual con el fin de que contenga las entradas asociadas al
  ambiente Kubernetes de desarrollo que aparecen en el ejemplo. Esta
  configuración es necesaria sobretodo utilizando conexión mediante VPN
  TINET.

* Configuración javaDoc ([~/eclipse-workspace](config/java/eclipse/javadoc/javaDoc-tinet-habitat.xml)).
  Esta configuración es necesaria para poder generar la documentación del
  codigo de los componentes java que se desarrollarán en el proyecto.

  ![Importación JavaDoc en Eclipse](config/java/eclipse/javadoc/javaDoc-demo-eclipse.gif)

* Configuración Formato ([~/eclipse-workspace](config/java/eclipse/formato/formato-tinet-habitat.xml)).
  Esta configuración es necesaria para manter un estandar de formato de codigo transversal
  en los proyectos java.

  ![Importación Formato en Eclipse](config/java/eclipse/formato/formato-demo-eclipse.gif)
  