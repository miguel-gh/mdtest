# Revisión de Pares (Pull-Requests) #

El presente documento describe el proceso y las reglas del juego del
***equipo nueva web*** para realizar la revisión de pares (PR) tanto para
autores como para revisores.

## Procedimiento de PR del equipo ##

1. El desarrollador de la funcionalidad debe ***proponer una fecha y hora***
    aproximada de generación del pull-request.

2. El desarrollador de la funcionalidad debe ***solicitar los revisores***
    comprometidos con su futura revisión.

3. Los revisores ***reservarán espacio en su agenda*** a la hora especificada
    para realizar la revisión (internos y externos al equipo).

4. Llegado el momento de generar el PR, este será enviado utilizando
    Bitbucket e ***incorporando a los revisores*** comprometidos en la
    revisión.

5. Los revisores realizarán la revisión inicial ***dentro del horario***
    programado. Luego de la revisión inicial se generarán conversaciones y
    se tomarán acuerdos respecto a la mejor forma de resolver la problemática
    identificada en los comentarios.

6. Las ***correcciones serán realizadas por el autor*** de la funcionalidad,
    aunque puede también ser ayudado por el resto del equipo que quiera
    colaborar.

7. El PR se aprobará o descartará en función de las observaciones.

## Reglas del juego del proceso ##

Las siguientes son las reglas del juego que el equipo nueva web define para
su proceso de revisión de pares:

### Reglas del juego para autores ###

- Mínimo ***2 revisores del mismo equipo*** al que pertenece el autor,
    aunque puede requerirse más aprobaciones si se considera apropiado.
- Mínimo ***1 revisor externo*** al equipo del autor del PR, aunque
    puede requerirse más aprobaciones si se considera apropiado.
- Los PR deben ser ***de tamaño reducido*** con el fin de facilitar la
    revisión y reducir los tiempos necesarios para analizar.
- La ***descripción debe ser clara y precisa*** de los PR es necesaria para
    facilitar la comprensión del cambio a los revisores y evitar así malos
    entendidos.
- Los PR deben considerar ***un solo cambio a la vez*** (no multiples
    funcionalidades o ajustes), para facilitar la revisión y para reducir
    la posibilidad de que algo se pase sin revisar.
- ***No mezclar cambios*** de tipo refactor con cambios relacionados con
    lógica o funcionalidades.
- Los autores deben recibir los comentarios a su pull-request con buena
    disposición, y ***sin atribuirle mala intención, entonación o emoción***.

### Reglas del juego para revisores ###

- Lo primero y más importante es ***entender el objetivo del cambio*** y
    revisar el código en función de dicho objetivo.
- Debe ***revisar todas y cada una*** de las líneas de código asociadas al
    pull-request en la revisión.
- Los comentarios y observaciones ***deben referirse al código fuente***,
    no al desarrollador. Deben ser propositivos buscando mejorar la calidad
    del desarrollo.
- Los revisores realizarán la revisión ***durante el horario comprometido***
    y agendado.
- El revisor buscará ***mejorar la calidad del producto*** desarrollado,
    recordando que "Lo perfecto es enemigo de lo bueno".

## Consideraciones de desarrollo y revisión ##

Los aspectos a revisar deben ser priorizados en el siguiente orden:

### 1) Aspectos prioritarios ###

> ***NOTA:*** Si se detectan problemas de este tipo, se deben considerar
> prioritarios y reportarlos lo más pronto posible.

- Determinar que los cambios se están realizando en el repositorio y en el
    componente correcto. Puede darse el caso de que estos cambios deban, por
    diseño, incorporarse en otro componente e incluso en un nuevo repositorio.
- Verificar si es que luego de los cambios el proyecto puede ser compilado,
    empaquetado, si es que se pueden ejecutar las pruebas de forma exitosa
    y si es que se cumple con el umbral de cobertura de pruebas (60% mínimo).
- Verificar que la ubicación de clases obedece la estructura de packages que
    define el arquetipo de proyectos java/angular.

### 2) Aspectos relacionados con la calidad ###

- Revisión de construcción de métodos, busqueda de posibles bugs, errores de
    construcción o complejidad excesiva o innecesaria en métodos.
- Uso correcto de framework Spring (anotaciones), registro de log de utilidad
    para la identificación de problemas y depuración de defectos, así como
    manejo correcto de excepciones e implementación práctica de las pruebas
    unitarias.
- Para documentacion en Java, aplicar el formato javadoc
    [definido para el equipo](config/java/eclipse/javadoc/javaDoc-tinet-habitat.xml).
- La documentación debe ser clara y precisa, permitiendo comprender como se
    debe utilizar cada elemento, qué significan sus parámetros, los valores
    de entrada permitidos y sus implicancias en el resultado.
- Documentación de clases debe contener descripción, autor y versión.
- Documentación de métodos debe tener descripción del método, parametros,
    retorno y excepciones.
- Documentación de atributos debe incluir descripcion clara y precisa.

### 3) Aspectos relacionados con la mantenibilidad ###

- Nombre de variables y métodos deben ser representativos, en español a menos
    que se trate de palabras comunmente usadas en inglés (login, por ejemplo)
    o prefijos y sufijos de clases y métodos relacionados con interfaces
    del framework o a estereotipos conocidos (get/set).
- Indentación y formato de código de acuerdo a
    [convención del equipo](config/java/eclipse/formato/formato-tinet-habitat.xml)).
- Ortografía en el código y especialmente en la documentación.

## Referencias y lecturas relacionadas ##

- [Estrategia de revisión de PR](https://docs.google.com/presentation/d/14WC8qMseIc9CPeTAr0RTl4776HS-NQbYBgcOgGeE77c/edit?usp=sharing).
- [Resumen de prácticas PR en Google](https://docs.google.com/presentation/d/1n8NiBx4hfVakvEqvnFQK5F_FENJTsOuPysNMRigxmt8/edit?usp=sharing).
- [Google Engineering Practices Documentation](https://github.com/google/eng-practices).

## Propuestas y pasos a seguir ##

- ¿Deberíamos crear un canal especial en `slack` para coordinar las
    revisiones de PR (solicitud de revisores, aclaraciones, acuerdos)?
- TODO: Uso de SonarQube y/o Lint como parte de la revisión.
