# AFP Habitat - Ejemplos Front #

Basado en el proyecto base de nueva web.

Proyecto util-ejemplos web , contiene distintos ejemplos de componentes html que son 
utilizados en la nueva web.

Se recomienda su uso , para no crear nuevos estilos y mantener un estandar en el desarrollo a nivel de front.

## Comenzando ##

### Pre-requisitos ##

- Editor de código [Visual studio code](https://code.visualstudio.com)

- Herramienta opcional para gestionar (push,pull,merge,commit,checkout,etc) repositorios GIT [Sourcetree](https://www.sourcetreeapp.com/)

- EditorConfig
  - ¿Qué hace?: Setea configuraciones del editor comunes para el equipo mediante un archivo que se encuentra en el proyecto.
  - [Plugin VS Code](https://marketplace.visualstudio.com/items?itemName=EditorConfig.EditorConfig)
  - [Página oficial](https://editorconfig.org)

- TSLint
  - ¿Qué hace?: Analiza el código typescript y muestra errores o malas prácticas que podamos cometer.
  - ¿Cómo se configura?: Archivo `tslint.json` en la raiz del proyecto.
  - [Plugin VS Code](https://marketplace.visualstudio.com/items?itemName=ms-vscode.vscode-typescript-tslint-plugin)
  - [Página oficial](https://palantir.github.io/tslint/usage/cli)

- Node JS + NPM ( Sistema de gestión de paquetes por defecto para Node.js)
  - [WEB](https://nodejs.org/es)
  - Instalación: Ejecutable versión 12.16.1

- Angular CLI.
  - [WEB](https://cli.angular.io)
  - Instalación: `npm install -g @angular/cli`

- NX CLI ( Utilizando para comandos nx ).¡
  - [WEB](https://nx.dev/web/guides/cli#installing-the-cli)
  - Instalación: `npm install -g @nrwl/cli`

- Validador de archivos markdown.
  - [WEB](https://marketplace.visualstudio.com/items?itemName=DavidAnson.vscode-markdownlint)

- Consola de administración NGXS
  - [WEB](https://github.com/ngxs/cli)
  - Instalación: `npm i @ngxs/cli -g`

- Pluggin devtools Redux ( Utilizado para desarrollar con ngxd )
  - [WEB](https://github.com/zalmoxisus/redux-devtools-extension)

### Instalación de dependencias ###

Instalar dependencias del proyecto (configuradas en archivo package.json).
Este paso es necesario antes de poder hacer cualquier cosa en el proyecto
y se debe volver a realizar cada vez que una nueva dependencia se incorpora
al proyecto global.

`npm install`

Con este paso completado se puede comenzar a utilizar el espacio de trabajo.

### Correr proyecto ejemplos-front ###

`npm install`

## Construido con ##

- Workspace creado con [Nx](https://nx.dev).
- [10-minute de video introductivo](https://nx.dev/angular/getting-started/what-is-nx)

## Autores ##

- **Francisco Mendoza** - *Trabajo Inicial* - fmendoza@tinet.cl
- **Roxana Carrera** - *Proyecto base* - roxana.carrera@tinet.cl
- **Andrés Arce** - *Proyecto base* - andres.arce@tinet.cl
- **Roberto San Martín** - *Deployment Kubernetes* - rsanmartin@tinet.cl

## Información de utilidad ##

- [wiki angular](https://bitbucket.org/Tinet/nueva-web-front/wiki/Home)

## Expresiones de Gratitud ##

- Comenta a otros sobre este proyecto 📢
- Invita una cerveza 🍺 a alguien del equipo.
- Da las gracias públicamente 🤓.
- etc.
