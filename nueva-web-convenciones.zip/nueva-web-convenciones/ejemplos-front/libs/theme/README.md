# Theme de assets compartidos para todos los proyectos Angular

Librería Generada con [Nx](https://nx.dev).

Contiene:

- Fuentes & Icons.

- SCSS.
  
- Imágenes.

## Como agregar las fuentes y/o estilos generales a nuestro proyecto en tres pasos

Ir al archivo angular.json

- Agregar este extracto de código en la ruta : "nombre_proyecto.architect.build.options.assets"

```css
  {
    "glob": "**/*",
    "input": "libs/theme/src/lib/fonts",
    "output": "/fonts/"
  }
```

- Agregar lo siguiente al final de la ruta "nombre_proyecto.architect.build.options" (post scripts)

```css
  "stylePreprocessorOptions": {
    "includePaths": [
      "libs/theme/src/lib/scss"
    ]
  },
  "extractCss": true
```

- Por último, en el archivo "styles.scss" de nuestro proyecto agregamos el import

```css
@import "fuentes";
```

También, en el archivo "styles.scss" podemos agregar "global", el cual importará todos los estilos generales (también se pueden importar por separado, dependiendo del uso)

```css
@import "global";
```

Con lo anterior, se pueden utilizar las fuentes del proyecto lib theme.

Un ejemplo de cómo utilizar la fuente:

```css
.etiqueta {
  font: 14px $font-bold;
}
```

## Util

- [Cómo agregar las fuentes a la carpeta assets del proyecto / stackoverflow](https://stackoverflow.com/questions/57243369/managing-shared-styles-and-assets-in-ngrx-nx-monorepo)

- [Cómo agregar scss y luego utilizar import en nuestro proyecto](https://github.com/nrwl/nx/issues/1542)

## Como utilizar data-break

1.- Se debe agregar al angular.json al proyecto que se necesite utilizar
  Ej
  ```json
    "libs/theme/src/lib/js/main.js"
  ```
  
  ```json
    "scripts": [
				"node_modules/jquery/dist/jquery.min.js",
				"node_modules/popper.js/dist/umd/popper.min.js",
				"node_modules/bootstrap/dist/js/bootstrap.min.js",
				"libs/theme/src/lib/js/main.js"
			],
  ```
2.- Se debe agregar el atributo data-break a la tabla
  Ej
     <table data-break="668">
  Donde
    data-break
      Es la cantidad de pixeles que se debe tener para forzar al objeto a ser responsivo, en este caso 668px.

