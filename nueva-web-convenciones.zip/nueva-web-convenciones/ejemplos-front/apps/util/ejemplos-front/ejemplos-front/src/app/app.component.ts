import { Component } from "@angular/core";
import { PageChangedEvent } from 'ngx-bootstrap/pagination';

export class Developer {
  nombre: string;
  apellido:string;
}

@Component({
  selector: "afp-habitat-sitio-privado-root",
  templateUrl: "./app.component.html",
  styleUrls: ["./app.component.scss"],
})
export class AppComponent {
  public developers: Developer[];
  totalItems: number;
  page: number;
  previousPage: number;

  constructor() {
  }
  ngOnInit() {
    this.totalItems = 50;
    this.page =0;
    this.previousPage =0;
    this.fillDevelopers(this.page);
  }

  private fillDevelopers(page : number) {
    this.developers = [];

    for (let index = 0; index < 10; index++) {
      let developer = new Developer();
      developer.nombre = 'nombre' + page + index;
      developer.apellido = 'apellido' + page + index;
    
      this.developers.push(developer);
    }
  }

  loadPage(pageEvent: PageChangedEvent) {
    if (pageEvent.page !== this.previousPage) {
      this.previousPage = pageEvent.page;
      this.fillDevelopers(this.page -1);
    }
  }
}
