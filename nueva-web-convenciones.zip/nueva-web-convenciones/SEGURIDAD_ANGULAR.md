# Seguridad del desarrollo en Angular

## Contexto general

El fin de esta guía es describir normas, recomendaciones y prácticas
que nos permitirán desarrollar aplicaciones angular que minimicen el
riesgo de ser vulnerables a ataques por parte de usuarios
malintencionados.

Esta guía ***debe ser conocida y aplicada por todos los integrantes
de los equipos desarrollo*** del proyecto Nueva Web de AFP Habitat.

## Tipos de vulnerabilidades

### Cross-Site Scripting (XSS)

- Este tipo de vulnerabilidad permite a un atacante el inyectar
  código malicioso en nuestra aplicación (por ejemplo un
  `<script>` que envíe información sensible desde nuestro sitio).
- Para que esto ocurra, el atacante debe de alguna forma ingresar
  codigo ejecutable al DOM de la aplicación. Un desarrollo
  vulnerable puede estar incorporando como parte de la página
  valores ingresados por el usuario sin preocuparse de "sanitizarlos"
  previamente.

### Cross-Site Request Forgery (CSRF/XSRF)

- Este tipo de vulnerabilidad permite a un atacante realizar
  peticiones en nuestra aplicación usando la identidad de un usuario
  con la sesión previamente iniciada.
- La petición de ataque puede originarse, por ejemplo, en otro sitio
  que cuente con un enlace a nuestro sitio realizando una petición
  HTTP en nombre del usuario con la sesión iniciada.

### Cross-Site Script Inclusion (XSSI)

- Este tipo de vulnerabilidad permite a un atacante el incorporar
  en nuestra aplicación un código malicioso mediante el uso de una
  antigua falla en los navegadores más antiguos que interpretaba las
  respuestas JSON de las llamadas AJAX como código ejecutable.

## Normativas generales

- Utilizar ***la ultima versión LTS*** de angular disponible. Si
  existen nuevas versiones, evaluar el mantener el proyecto
  actualizado.
  Acá la [ruta del changelog](https://github.com/angular/angular/blob/master/CHANGELOG.md).
- No modificar, con código propio, la versión de angular que utilice.
  Al hacerlo puede estar introduciendo, de forma consciente o
  inconsciente, vulnerabilidades a la aplicación.
- Evitar el uso de componentes angular que ***se encuentren marcados***
  con posibilidad de introducir vulnerabilidades ("Security Risk").
  Un ejemplo [se encuentra acá](https://angular.io/api/core/ElementRef#security-risk)
  En caso de que sea muy necesario, tomar las medidas para mitigar
  la posibilidad de ocurrencia de dicho riesgo incorporando también
  al resto del equipo en la decisión y generación de alternativas.

## Normativas para el desarrollo

Las siguientes son normativas importantes que se deben aplicar a la
hora de desarrollar como parte del equipo Angular. En general, estas
normativas permiten defender nuestro DOM y asi evitar que pueda ser
aprovechado por un atacante para ejecutar código malicioso.

### No generar código vulnerable al XSS

- En general Angular maneja todos los valores que se agregan al DOM
  (propiedades, atributos, css, binding de clases o interpolación)
  como valores inseguros y por lo tanto ***siempre los "sanitiza"***
  antes de desplegarlos en la aplicación.
  - La sanitización implica que cualquier texto "ejecutable" como
    por ejemplo, un bloque `<script>` almacenado como texto dentro
    de una variable, no sea interpretado (ni ejecutado) como tal
    por el navegador a la hora de visualizarlo, sino que sea tratado
    por el mismo ***como texto inofensivo***.
  - Cualquier caracter o secuencia de caracteres especiales que
    vuelva al texto potencialmente ejecutable es reemplazado por
    su versión con caracteres "escapados". Esto hará que el texto
    ***se visualice correctamente*** en la pantalla, pero lo volverá
    ***inservible*** desde un punto de vista funcional.
  - Para más información respecto de la sanitización de valores,
    refiérase al [siguiente enlace](https://angular.io/generated/live-examples/security/stackblitz.html).
- Este comportamiento, sin embargo, puede ser evitado mendiante el
  uso de funciones que permiten marcar de forma explícita ciertos
  valores ***como confiables***. Algunas de estas funciones son las
  siguientes:
  - bypassSecurityTrustHtml
  - bypassSecurityTrustScript
  - bypassSecurityTrustStyle
  - bypassSecurityTrustUrl
  - bypassSecurityTrustResourceUrl
- Al respecto de las funciones mencionadas, la regla general para
  el equipo es ***NO UTILIZARLAS*** en nuestro desarrollo. Esta norma
  deberá ser aplicada en nuestro proceso de revisión de pares con el
  fin de que cualquier potencial vulnerabilidad sea solucionada antes
  de mezclar el código en la rama de desarrollo.
- En los ***casos excepcionales*** en los cuales estas funciones se
  utilicen deberán ser discutidos y aclarados con el equipo con el
  fin de asegurar que los valores involucrados son ***confiables***
  y que ***de ninguna forma*** representan una vulnerabilidad en la
  aplicación. *Uno de los casos excepcionales desde ya identificados
  será el despliegue de aplicaciones Weblogic dentro de un `iframe`
  en nuestra aplicación angular del portal privado*.

### No manipular manualmente el DOM (Ejemplo: jQuery)

- Angular manipula el DOM de la aplicación en forma segura, evitando
  introducir vulnerabildades dentro de nuestra aplicación.
- Con el fin de no generar vulnerabilidades se debe evitar manipular
  externamente el DOM de la aplicación. Todo control de visualización
  o generación dinámica de contenido HTML debe realizarse mediante
  mecanismos Angular normales (directivas).
- No utilizar dependencias que permitan manipular externamente el DOM
  de la aplicación. En nuestro caso, debido al uso de Bootstrap nos
  vemos forzados a incorporar jQuery como dependencia.
- A pesar de eso el equipo ***NO DEBE UTILIZAR jQuery*** al
  desarrollar las funcionalidades.

### Utilizar Compilador Offline (AOT)

- Angular permite realizar dos clases de compilación de plantillas
  HTML que componen la aplicación: AOT (Ahead Of Time) y JIT (Just
  In Time).
- AOT corresponde a una compilación temprana de las plantillas, antes
  de que estas sean instaladas en el servidor Web donde residirán.
  Esto beneficia tanto desde el punto de vista de rendimiento a la
  aplicación como desde un punto de vista de seguridad.
  [Documentación aquí](https://angular.io/guide/aot-compiler).
- JIT corresponde a una compilación on demmand en el navegador, una
  vez descargados los fuentes de la aplicación. Esta solo debe
  utilizarse en tiempo de desarrollo para facilitar la depuración.
  [Documentación aquí](https://angular.io/guide/glossary#jit).
- Con el fin de mejorar el rendimiento y evitar potenciales
  vulnerabilidades en la aplicación, la forma de despliegue del sitio
  en producción será ***utilizando compilación AOT***.
- En ambiente local, se puede utilizar compilación JIT.

### Definiciones de Content Security Policy (CSP)

- Es una técnica de defensa en profundidad para prevenir
  vulnerabilidades de tipo XSS.
- Para habilitar CSP, configure su servidor web para que devuelva un
  encabezado HTTP Content-Security-Policy apropiado.
- Este encabezado, configurado de una forma restrictiva permite al
  navegador impedir el funcionamiento de ciertas características que
  corresponden a vectores para la ejecución maliciosa de código por
  parte de un atacante.
- Algunos ejemplos corresponden a restringir los dominios de origen
  desde los cuales se puede cargar contenido HTML en un iframe, o
  desde los cuales se puede obtener scripts ejecutable, hojas de
  estilo, si es que se puede incluir o no scripts u estilos CSS de
  forma inline dentro de las páginas, o si es que se puede o no
  evaluar textos e interpretarlos como scripts ejecutables.
- La configuración de CSP en la aplicación angular será realizada
  de forma restrictiva, evitando la evaluación de scripts y estilos
  CSS en línea, y restringendo a la carga de recursos HTML, CSS y
  JS a orígenes confiables (dominio nuevo y weblogic).
- Desde el punto de vista del equipo de desarrollo, es importante
  conocer de las restricciones antes mencionadas, con el fin de
  no utilizar las características que serán bloqueadas.
- El listado concreto de características permitidas por el CSP
  será publicado al equipo y actualizado conforme se determine
  pertinente para evitar la existencia de vulnerabilidades. La
  versión inicial de dicho listado se encuentra en el
  [siguiente documento](CSP.md)

### Vulnerabilidades a nivel HTTP

- Angular tiene soporte incorporado para ayudar a prevenir
  vulnerabilidades HTTP comunes como las mencionadas anteriormente
  (CSRF/XSRF, XSSI).
  - Para complementar estas defensas y permitirles funcionar de forma
    correcta, se requiere realizar ciertos ajustes por el lado del
    servidor (web/backend) que permitan realizar una comprobación
    de que el request recibido se origina en la aplicación de
    confianza.
    - [Ver información acá](https://angular.io/guide/security#xsrf).
  - También se recomienda que las respuestas JSON de los servicios
    del backend no sean ejecutables para evitar la posibilidad de
    ataques de tipo XSSI.
    - [Ver detalles acá](https://angular.io/guide/security#xssi).
    - [Una posible solución acá](https://stackoverflow.com/questions/26384930/how-to-add-n-before-each-spring-json-response-to-prevent-common-vulnerab).
- Para evitar que la información intercambiada entre los usuarios y
  el sitio o el backend sea de alguna forma interceptada y manipulada
  por algún atacante, ***todo tráfico debe ser realizado***
  utilizando protocolo HTTPS.
- Para evitar que un usuario no autorizado realice invocaciones en
  forma directa a alguno de los servicios de nuestra API, toda
  llamada ***debe incorporar un "Access Token"*** obtenido durante
  la autenticación del usuario contra el servidor OAuth 2.0 del
  sistema. En angular, esto será resuelto mediante el uso de un
  interceptor de peticiones HTTP.

## Buenas prácticas a considerar

### Iframes para contener aplicaciones

- La solución actual considera el ***uso de iframes*** para desplegar
  tanto las aplicaciones legadas existentes en weblogic, como también
  las nuevas aplicaciones angular que se irán migrando durante
  el desarrollo.
- Para soportar esta característica es importante considerar que
  las variables que contengan las URL a estas aplicaciones deberán
  ser explícitamente ***excluidas de la sanitización***.
- El origen de los datos de estas variables debe, por lo mismo, ser
  ***absolutamente confiable***.

### Manipulación de información sensible

- Se debe tener mucho cuidado con la forma de manipular valores
  que sean de naturaleza sensible (credenciales del usuario, tokens
  de acceso, secrets de seguridad, entre otros).
- En la manipulación de este tipo de valores se debe considerar:
  - ***No almacenar*** dichos valores en multiples lugares diferentes
    como local storeage, session storage o parámetros.
  - ***Usar REDUX*** como mecanismo de almacenamiento y actualización
    de dichos valores y sólo en caso de ser necesario.
  - ***Nunca registrar log utilizando valores sensibles***, o sus
    derivados en el log de la aplicación.

### Sobre las dependencias NPM

- Cuando un caso de uso requiere la búsqueda y utilización de una
  biblioteca adicional externa, es indispensable considerar el no
  utilizar dependencias que introduzcan vulnerabilidades al sistema
  (sobretodo de niveles medio/alto).
- En caso de duda, levanta la mano y convérsalo con el resto del
  equipo del proyecto.

### Manejo de warnings en dependencias NPM

Al ejecutar `npm install`, es posible que se desplieguen algunas
advertencias. Por ejemplo:

```bash
found 5 vulnerabilities (1 low, 2 moderate, 1 high)
  run "npm audit fix" to fix them, or "npm audit" for details
```

En estos casos, se recomienda utilizar el comando `npm audit fix`,
el cual solucionara estos problema.

Nuestro objetivo como equipo es mantener en 0 las vulnerabilidades y
dar prioridad a advertencias altas y moderadas.

El comando `npm audit` muestra el detalle de estas vulnerabilidades.
Incluso existe el apartado de ***More info*** que cual muestra una
url con el detalle preciso del problema.

A continuación encontrarás enlaces con antecedentes adicionales
asociados a cómo resolver problemas en las dependencias del proyecto.

- [Auditing package dependencies for security vulnerabilities](https://docs.npmjs.com/auditing-package-dependencies-for-security-vulnerabilities)
- [NPM Audit: identify and fix insecure dependencies](http://blog.npmjs.org/post/173719309445/npm-audit-identify-and-fix-insecure)
- [NPM Audit avisa de las vulnerabilidades en las dependencias](https://www.todojs.com/npm-audit-avisa-de-vulnerabilidades/)
  
## Otras referencias

- [Angular Security Best Practices](https://ordina-jworks.github.io/angular/2018/03/30/angular-security-best-practices.html).
- [Angular Security](https://angular.io/guide/security).
- [Top 5 Best Practices for Angular App Security](https://www.syncfusion.com/blogs/post/top-5-best-practices-angular-app-security.aspx).
- [ANGULAR SECURITY BEST PRACTICES](https://www.cisin.com/coffee-break/technology/angular-security-best-practices.html).
- [Comparing React and Angular secure coding practices](https://snyk.io/blog/comparing-react-and-angular-secure-coding-practices/).
