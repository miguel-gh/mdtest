# Seguridad Java Backend

La presente guia pretende definir las recomendaciones de seguridad
que el equipo de desarrollo de la Nueva Web debe seguir a la hora de
desarrollar servicios REST en lenguaje Java.

## Vulnerabilidades comunes en desarrollo Java

A continuación se describen algunas vulnerabilidades que es
importante conocer y evitar a la hora de desarrollar aplicaciones de
tipo backend en lenguaje Java.

### Inyección de SQL (SQL Injection)

- Este tipo de vulnerabilidad permite a un eventual atacante ejecutar
  sentencias SQL sobre la base de datos del sistema a voluntad, fuera
  más allá de las sentencias y consultas habilitadas por el
  desarrollador como parte de las funcionalidades del sistema.
- Se produce cuando algún dato enviado como parámetro en la
  invocación a un determinado servicio se utiliza en forma directa
  (sin sanitización) para formar parte de una sentencia SQL que se
  ejecutará contra la base de datos.
- Los efectos de que un atacante explote una vulnerabilida de este
  tipo pueden ir desde la obtención de información sensible sin la
  debida autorización, hasta la modificación o eliminación de datos
  o de la estructura de la base de datos en cuestión.
- Más información respecto de este tipo de vulnerabilida puede ser
  revisada [en el siguiente enlace](https://owasp.org/www-community/attacks/SQL_Injection).

### Cross-Site Request Forgery (XSRF/CRSF)

- Este tipo de vulnerabilidad permite a un atacante realizar
  peticiones en nuestra aplicación usando la identidad de un usuario
  con la sesión previamente iniciada.
- La petición de ataque puede originarse, por ejemplo, en otro sitio
  que cuente con un enlace a nuestro sitio realizando una petición
  HTTP en nombre del usuario con la sesión iniciada.

### Cross-Site Script Inclusion (XSSI)

- Este tipo de vulnerabilidad permite a un atacante el incorporar
  en nuestra aplicación un código malicioso mediante el uso de una
  antigua falla en los navegadores más antiguos que interpretaba las
  respuestas JSON de las llamadas AJAX como código ejecutable.

### Modelado vulnerable

- Este tipo de vulnerabilidad permite a un programa que haga uso de
  una biblioteca java el manipular o modificar el estado interno de
  las instancias de una determinada clase de dicha biblioteca sin
  notificar dicho cambio a la instancia afectada.
- Este tipo de vulnerabilidad puede generar, desde errores o
  comportamiento impredecible, hasta manipulación mal intencionada de
  nuestro código (para evitar validaciones de negocio, por ejemplo).
- La vulnerabilidad se genera cuando nuestro código no protege
  correctamente su estado interno, entregando referencias de
  objetos mutables directamente, o almacenando referencias mutables
  como variables de instancia.

### Validación insuficiente de datos/negocio

- Este tipo de vulnerabilidad permite a un usuario malintencionado
  realizar la invocación de operaciones no permitidas desde un punto
  de vista de negocio.
- Una validación insuficiente de los datos podría permitir a un
  usuario realizar operaciones de consulta o transacciones sobre
  recursos que no le pertenecen mediante la manipulación de
  los parámetros de los servicios expuestos.
- Una validación insuficiente del negocio podría permitir a un
  usuario realizar operaciones omitiendo pasos de validación
  existentes en la aplicación Web invocando de forma directa a
  los servicios que carezcan de validaciones de negocio que
  permitan impedirlo.

### Autorización insuficiente

- Este tipo de vulnerabilidad puede permitir a un usuario con malas
  intenciones el obtener acceso permanente o temporal a datos
  sensibles o realizar transacciones en nombre de otro usuario.
- Surge de no considerar suficientes mecanismos de control en toda
  o parte de la API publicada, así como tambien el no discriminar
  con niveles diferenciados el acceso otorgado mediante los
  mecanismos de autenticación utilizados.
- También puede surgir de la implementación de mecanismos de
  seguridad que no sean algún estandar de la industria (como JWT/
  OAuth/OIDC) o que no realice todas las verificaciones que el
  estandar recomienda para cada situación.

## Top 10 de vulnerabilidades en API (OWASP)

El [Open Web Application Security Proyect](https://owasp.org/)
(OWASP) es una organización sin fines de lucro destinada a promover
la aplicación de prácticas de seguridad en el desarrollo de software.

Parte de su función consiste en identificar, clasificar y describir
vulnerabilidades en el software, y a la misma vez proponer técnicas
y prácticas que permitan evitar la existencia o la explotación de
dichas vulnerabilidades.

Una iniciativa liderada por OWASP consiste en rankear las más
importantes vulnerabilidades existentes en el desarrollo de sitios
Web y de APIs, que describimos [en la siguiente sección](OWASP.md).

> NOTA: El área de ciberseguridad de AFP Habitat declaró que su
> principal foco de seguridad sera asegurar que nuestro desarrollo
> no presenta ninguna de las vulnerabilidades del [Top 10 OWASP
> para APIs](https://owasp.org/www-project-api-security/).

## Normativas de desarrollo seguras

A continuación se describen las normativas que debe seguir todo
integrante del equipo de desarrollo backend en Java para el proyecto
Nueva Web de AFP Habitat.

### Siempre sanitizar valores inseguros

Considere cualquier valor que llega como parámetro dentro de una
solicitud a la API como inseguro. Esto quiere decir que puede
contener un intento de vulnerar de alguna forma la seguridad de
la aplicación.

La normativa en este caso consiste en siempre sanitizar los
valores antes de utilizarlos en una interacción con la base de
datos en parte de una respuesta al navegador que la envió.

En el caso de uso de parámetros para una interacción con la
base de datos, asegúrese de usar los mecanismos propuestos
por el framework para el reemplazo de variables en la sentencias
SQL (JDBC/JPA). ***NUNCA construya sentencias SQL concatenando***
Stirngs con parámetros de la solicitud.

### Configurar prefijo en respuesta JSON

Con el fin de evitar vulnerabilidades de tipo XSSI, es necesario
asegurarse de que las respuestas JSON de los servicios desarrollados
no sean interpretados como un script evaluable en los navegadores
más antiguos.

> NOTA: Evaluar la posibilidad de utilizar un componente de
> configuración similar a lo indicado [en la siguiente solución](https://stackoverflow.com/questions/26384930/how-to-add-n-before-each-spring-json-response-to-prevent-common-vulnerab.)

### Desarrollo a la defensiva

Durante el desarrollo, siempre ponerse en el caso de que un usuario
malintencionado intentará sacar provecho de las funcionalidades o
servicios que se están publicando.

Modelando entidades, value objects y servicios. ¿Como evitar que
el estado de las instancias se mantenga siempre consistente? ¿Es
posible que estado interno de las instancias de clases pueda ser
corrompido o manipulado de forma inadvertida? ¿Pueden las
validaciones implementadas ser evitada o burladas de alguna forma?

Implementando una API de servicios. ¿puede un usuario realizar una
consulta de datos sensibles o transacción no autorizada en nombre
de otro usuario del sistema? ¿Puede manipular los parámetros de
entrada del servicio para conseguir un comportamiento alternativo
diferente del que fue originalmente desarrollado? ¿Qué consecuencias
podría provocar dicho uso alternativo? ¿Existe la posibilidad de
que el sistema sea engañado mediante alguna manipulación de los
parámetros de entrada del servicio? ¿O podría algún usuario evitar
validaciones invocando directamente un servicio transaccional, sin
utilizar la aplicación Web diseñada para ello?

Siendo capaces de responder con tranquilidad estas preguntas, será
posible reducir al máximo la cantidad de vulnerabilidades de nuestro
desarrollo.

### Validación contra Auth Server (OAuth 2.0)

Todos los servicios de la API deben estar protegidos mediante alguno
de los flujos de autenticación proporcionados por OAuth2/OIDC.

En el caso de los servicios de autenticación, deben considerar
algun mecanismo que permita protegerlos contra ataques de tipo
fuerza bruta o similares. Un ejemplo puede ser el bloqueo de las
credenciales en caso de un exceso de reintentos fallidos.

Spring security proporciona mecanismos para segurizar utilizando
el estandar OAuth2. [Revise acá la documentación](https://docs.spring.io/spring-security/site/docs/5.3.0.RELEASE/reference/html5/#oauth2resourceserver).

### Implementar protección XSRF/CRSF

Con el fin de evitar potenciales vulnerabilidades de tipo XSRF/CSRF,
una técnica consiste en enviar un token mediante una cookie al
navegador que está interactuando con la API. Cada solicitud enviada
posteriormente al servidor debe incluir una cabecera con el valor
de dicho token. Como solamente la página que realizó la solicitud
tiene acceso a dicha cookie, solo ella puede incorporar el header
con dicho valor en la nueva solicitud.

El siguiente bloque de código presenta un ejemplo de implementación
del mecanismo de defensa contr vulnerabilidades de este tipo (1)
utilizando Spring Security.

```java
@EnableWebSecurity
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http
            .csrf()
                .csrfTokenRepository(CookieCsrfTokenRepository.withHttpOnlyFalse());
    }
}
```

Angular soporta de forma natural este mecanismo como indica su
[documentación](https://angular.io/guide/security#xsrf).

> NOTA 1: Si bien existen posibles mecanismos para incorporar protección
> contra ataques del tipo XSRF/CRSF implementables en Spring mediante
> un token de verificación, esta alternativa no considera el escenario
> de múltiples aplicaciones java de tipo stateless procesando
> solicitudes de tipo AJAX. La protección utilizando un token OIDC/OAuth2
> ya protege contra este tipo de ataques por lo que la presente sección
> ***debe considerarse como informativa, pero no mandatoria*** a la hora
> de desarrollar componentes de la solución.
