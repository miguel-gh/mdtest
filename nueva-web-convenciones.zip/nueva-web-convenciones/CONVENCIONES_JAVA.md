# Convenciones de código Java #

Este documento incorpora las convenciones del equipo respecto de normas y
buenas prácticas de codificación en lenguaje Java.

## Convenciones y normas generales ##

A continuación se incorporan algunas definiciones acordadas con el equipo
con el fin de mejorar la calidad del producto desarrollado que han surgido
con el tiempo durante el desarrollo del proyecto.

1. ***Evitar utilizar bibliotecas existentes de AFP Habitat*** en los
    desarrollos Java de la nueva web. Esto tiene como objetivo
    **reducir el acoplamiento** con el código actual por lo que cada caso
    excepcional debe ser acordado con el equipo y con el arquitecto del
    proyecto. Preferir en los casos que sea posible el uso de
    **clases utilitarias Spring (o similares)** que cumplan con la
    función requerida.
2. ***La versión de Java para los desarrollos es 1.8***. El entorno de
    ejecución de los ambientes AFP Habitat (desarrollo/QA) está basado en
    la última versión disponible de OpenJDK 1.8 (1.8.0_242 al momento de
    redactar esta definición). Para evitar potenciales inconvenientes o
    problemas de compatibilidad todo el equipo de desarrollo de servicios
    debe usar esta misma versión. Puede encontrarla en alguno de los
    siguientes sitios:
    * [Sito de AdoptOpenJDK](https://adoptopenjdk.net/).
    * [Sitio oficial OpenJDK](https://openjdk.java.net/).

## Diseño de API ##

Los servicios de la API para la nueva web siguen los principios de la
arquitectura REST y por lo tanto corresponden a una API RESTful. La
siguiente sección presenta las implicancias de esto.

### Características de una API RESTful ###

La palabra API significa interfaz de programación de aplicaciones y se
refiere a un conjunto de funciones, reglas y documentación de uso y
datos que permiten a un componente interactuar con otro.

REST es una arquitectura que define recomendaciones y restricciones bajo
la cual se puede construir una API.

Una API RESTful es una API implementada siguiendo las recomendaciones REST.

En este sentido REST define que cada interacción con el servidor se realice
mediante peticiones compuestas por los siguientes elementos:

1. ***Verbo HTTP***: Describe el objetivo de la petición que se está
    realizando. Los verbos más utilizados son:
    * `GET`: Permite al cliente de la API solicitar la obtención del
        recurso especificado en la URL.
    * `POST`: Permite crear/enviar un nuevo recurso en el servidor. Los
        datos del nuevo recurso generalmente viajarán en el cuerpo de la
        solicitud.
    * `PUT`: Permite modificar un recurso existente en el servidor.
        Los datos del recurso a modificar viajarán en el cuerpo de la
        solicitud.
    * `PATCH`: Permite modificar solo parte del recurso a modificar.
        Los datos a modificar del recurso se envian en el cuerpo de la
        solicitud.
    * `DELETE`: Permite al cliente solicitar la eliminación del recurso
        especificado en la URL.
2. ***Dirección URL***: Permite indicar cual es el recurso al cual se asocia
    la solicitud. Dado que el verbo HTTP define la acción a realizar, la URL
    corresponde en general a una entidad u objeto sobre el cual se solicita
    realizar la acción especificada.
3. ***Datos***: Información necesaria para satisfacer el requerimiento.

Los servicios expuestos no deben almacenar estado (stateless). Esto implica
que cada petición enviada al servidor debe contener toda la información
necesaria para poder ser completada, incluyendo la información de
autenticación del cliente.

La respuesta de los servicios debe obedecer a la definición de los códigos
de estado HTTP. Es decir:

* `100–199`: Estados de información.
* `200–299`: Estados de éxito.
* `300–399`: Redirecciones.
* `400–499`: Errores del cliente.
* `500–599`: Errores del servidor.

> ***NOTA***: Para más información respecto de los significados de los códigos
> de estado [diríjase a la sigiuente página](https://developer.mozilla.org/en-US/docs/Web/HTTP/Status).

Algunos ejemplos de una APIs RESTful:

* `GET /api2/v1/empresas`: Permite al cliente obtener un listado de las
    empresas registradas en el sistema.
* `GET /api2/v1/empresas/73`: Permite al cliente obtener la empresa con el
    identificador `73`. Si es que el identificador no existe el servicio
    debería responder un código de estado `404`, por ejemplo.
* `DELETE /api2/v1/empresas/73`: Permite al cliente solicitar la eliminación
    de la empresa con el identificador `73`. Si es que el identificador no
    existe el servicio debería responder un código de estado `404`, por
    ejemplo.
* `POST /api2/v1/empresas`: Permite al cliente crear una nueva empresa en
    el sistema. Un código de estado `201` indicará la creación exitosa de
    la nueva empresa (especificada en el cuerpo de la solicitud). `200`
    también podría ser aceptable en caso de éxito en la creación.

> ***NOTA***: Diríjase al [siguiente enlace](http://confluence.afphabitat.cl/display/ARQ/Definiciones+API+Manager)
> para acceder a más información relacionada en AFP Habitat.

## Manejo de excepciones ##

Con respecto al manejo de excepciones en los componentes Java que
desarrollaremos, se debe tomar en consideración los siguientes aspectos:

### Modelado y manipulación de excepciones ###

Con relación al modelado y manipulación de excepciones en Java, se debe tomar
en cuenta las siguientes reglas del juego acordadas por el equipo:

1. Las excepciones de negocio deben incorporar un ***código de error***.
2. Los códigos de error de las excepciones de negocio se manejarán en un ENUM
    dado que son valores fijos propios de cada componente java desarrollado.
    La descripción del error también se debe almacenar en el mismo ENUM
    asociada al código correspondiente.
3. Los códigos de error deben tener la siguiente forma:
    * Prefijo (3 letras) + Correlativo (3 dígitos).
    * El prefijo debe representar al componente y es definido por el equipo
      (texto alfanumérico). ***No debe repetirse*** con el de otros
      componentes existentes.
    * El listado de componentes y prefijos de código de error se encuentra
      en [el siguiente enlace](https://docs.google.com/spreadsheets/d/17dMezyDybsI0Akb6Asgz2hhcjublSzy6ZxqCEoSMbq0/edit#gid=1839581764)
      (en la hoja "COMPONENTES").
    * El correlativo corresponde a un código numérico de 3 dígitos, partiendo
      desde cero. Un ejemplo de código de error sería: `XYZ001`.
4. Los mensajes de error desplegados en el front al usuario son responsabilidad
    de la capa front y no deben obtenerse directamente desde el servicio sino
    que traducirse desde el código del error.
5. Las excepciones de sistema no requieren código de error diferenciado. Solo
    basta con especificar una descripción del motivo del error. Normalmente
    significarán el lanzar un código HTTP de error de servidor (http 500).
6. Las excepciones de negocio y de servicio deben estar pesonalizadas al menos
    a nivel de componente (`LoginNegocioException`/`LoginSistemaException`
    por ejemplo). Una personalización más precisa por error de negocio se
    deja a criterio del equipo de desarrollo.

### Jerarquía de excepciones ###

La siguiente imagen representa la jerarquía de excepciones java. La idea es
***entenderla y utilizarla*** para mejorar nuestros desarrollos.

![Jerarquía de excepciones](images/excepciones.png)

Exiten 3 tipos de excepciones en java:

1. Excepciones chequeadas: Deben ser controladas (`try`/`catch`) o en su defecto
    declaradas en la sección `throws` de los métodos, de otra forma el código
    no podrá ser compilado. Estas representarán en nuestro caso a excepciones
    del negocio.
2. Excepciones no chequeadas: No es necesario que sean controladas o declaradas
    por los métodos dado que en general, no es mucho lo que el desarrollador
    pueda hacer para resolver el problema. En general se despliega un mensaje
    de error indicando con un mensaje la causa. Excepciones típicas de este
    tipo son `NullPointerException`, `IllegalArgumentException` o
    `RuntimeException`, entre otras.
3. Errores de la JVM: Otra categoría de tipos de excepciones es la rama de los
    Errors. En estos casos no es aconsejable que el código intente controlarlos
    así como declararlas en el throws. Representan situaciones de error graves
    como `NoClassDefFoundError` (la clase utilizada no existe) u
    `OutOfMemoryError` (no hay memoria disponible para crear nuevas
    instancias), entre otras.

## Requerimientos para el registro de Logs ##

Con el fin de obtener información de utilidad de los logs del componente
se definen los sigientes requerimientos importantes:

1. Cada operación relevante del flujo que implementa el componente backend
    debe incluir el registro de log en nivel `INFO` o superior una marca
    fácilmente identificable del resto del log que permita delimitar:

      * ***DESEABLE***: El inicio de la operación principal solicitada.
      * ***REQUERIDO***: El termino exitoso de la opearción principal.
      * ***REQUERIDO***: El termino fallido de la operación principal, ya sea
          por excepciones de negocio o de servicio.

    Enténdase por **operación relevante** las operaciones que contribuyen
    directamente con el propósito del componente desde el punto de vista
    funcional. Esto excluye las operaciones de registro de traza, por
    ejemplo.

2. Cualquier información de utilidad para la depuración del componente debe
    registrarse con nivel `DEBUG` o menor. Este nivel solo se habilitará
    en el ambiente de desarrollo y QA del sistema.
3. En caso de que se produzca una excepción, esta se debe registar en el
    log usando el método `logger.error(String, Throwable)` o similar
    que permita registrar la excepción causante. El nivel de registro
    dependerá de la gravedad.

      * ***WARN***: Indica una exepción que no representa un impedimento
          para que el flujo de ejecución continue.
      * ***ERROR***: Indica una excepción que impide que el flujo actual
          continue normalmente.
      * ***FATAL***: Indica un problema grave que puede afectar el
          funcionamiento del componente completo.

4. Evite la concatenación de variables en los mensajes de log. En vez de
    eso prefiera los métodos del logger que permitan el uso de parámetros
    de la forma `logger.debug(String, Object... args)` o similar.

## Consumo de servicios SOAP desde OSB ##

AFP Habitat posee un conjunto de componentes de tipo cliente WS SOAP que
permiten consumir las operaciones de los servicios web de tipo SOAP
publicados en los distintos tipos de bus de servicios existentes.

Estos clientes WS han sido desarrollados utilizando herramientas preparadas
para entornos de ejecución de servidores de aplicaciones JEE, pero que no
están diseñadas para un entorno multihebras standalone como el que utilizan
los componentes Java Spring Boot donde exponemos la API de la nueva web.
Esto genera un problema de acceso concurrente desde múltiles hebras de
ejecución que generarán errores de sistema muy complejos de replicar dado
que solo se producirán en escenarios de altísimo uso por parte de los
usuarios.

Para evitarlo, se deben tomar en cuenta las siguientes medidas:

1. Los componentes nuevos a desarrollar en el contexto del proyecto
    nueva web que requieran hacer uso de servicios SOAP existentes en
    AFP Habitat deben hacerlo utilizando la forma recomendada por
    spring para consumir dicho tipo de servicios. Esta manera se encuentra
    [publicada acá](https://spring.io/guides/gs/consuming-web-service/).
    Al hacerlo se deben tomar en cuenta las siguietnes reglas:

    * Cada cliente WS debe corresponder a un nuevo módulo dentro del
        componente que se está desarrollando (proyecto multimódulo). Para
        crear un nuevo módulo se pude utilizar algun otro proyecto similar
        o el comando `mvn archetype:generate` en la carpeta del proyecto
        maven principal (proyecto padre).
    * El archivo WSDL con la definición del servicio que se consumirá debe
        almacenarse dentro del proyecto, como parte del código fuente
        versionable. Para facilitar la copia completa (incluyendo esquemas)
        se puede utilizar el comando de exportación de SOAP-UI. El o los
        archivos exportados deben almacenarse en la carpeta
        `src/main/resources` del módulo creado.
    * Las clases del modelo que se obtienen desde el WSDL y desde los
        archivos XSD, se deben generar en forma automática, pero bajo
        ninguna circunstancia se deben versionar en el repositorio. Para
        ello, estas clases generadas deben almacenarse en la carpeta
        `target/` del módulo correspondiente.
    * Los nuevos módulos deben considerar el implementar test unitarios
        haciendo uso exhaustivo de mocks para evitar invocar realmente a los
        servicios del bus durante las pruebas unitarias.
    * En caso excepcionales, cuando no sea factible generar estos nuevos
        clientes SOAP para Spring debido a errores o problemas en los WSDL
        existentes se deberá recurrir a la opción mencionada en el siguiente
        punto.

2. Los componentes existentes que requieran consumir servicios SOAP deben
    contemplar el uso del utilitario
    [thread local](https://bitbucket.org/Tinet/thread-local-util/src/master/).
    Este utilitario permite evitar el acceso concurrente a la misma instancia
    de cliente WS SOAP de tipo AXIS o similar mediante el uso de un objeto
    thread-local.
    Esta herramienta también se podrá utilizar en caso en los que la creación
    del cliente WS de la forma recomendada por Spring no sea factible debido
    a problemas con el WSDL o similares.
