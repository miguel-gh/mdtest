# Content Security Policy

El presente documento corresponde a una versión tentativa del listado
de características permitidas o deshabilitadas por la politica de
seguridad de contenido.

Estas políticas se configuran a nivel de página individual con el fin
de permitir un absoluto control respecto de las posibilidades de carga
de contenido que tiene un sitio. Estas políticas son implementadas por
los navegadores modernos.

La configuración de CSP se realizará en el servidor web NGiNX donde
se alojarán las aplicaciones ángular.

## Normativas CSP Equipo Nueva Web

- base-uri: se utilizará para restringir la ruta base del dominio
  donde se desplegarán las páginas del sitio.
- child-src: con esta directiva se podrá especificar la carga de
  contenido HTML en iframes sólo desde el mismo dominio de la
  aplicación ángular y del dominio weblogic para las aplicaciones
  legadas.
- connect-src: esta directiva restringirá el origen de las llamadas
  a servicios REST al dominio donde publicaremos nuestras APIs
  (Kong API gateway).
- font-src: restringirá el origen de los fonts al dominio de la
  aplicación angular.
- form-action: restringirá el destino de las llamadas en formularios
  al dominio de aplicaciones angular.
- frame-ancestors: restringirá que las páginas de la aplicación
  angular solo puedan ser desplegadas en frames del mismo dominio.
- img-src: restringirá el origen de las imagenes a imágenes que
  se encuentren sólo en el mismo dominio.
- object-src: se restringirá para que no puedan utilizarse objetos
  en las páginas del sitio.
- plugin-types: se restringirá par que no puedan utilizarse objetos
  en las páginas del sitio.
- *report-uri (DEPRECADO)*: originalmente se propuso establecer una
  URL destino para registrar las violaciones al CSP configurada.
  Dado el actual estado, ***no se utilizará esta directiva***.
- style-src: se establecerá para solo cargar hojas de estilo CSS
  desde el dominio de la aplicación angular.

## Definiciones de directivas SCP

- base-uri: restringe las URL que pueden aparecer en el tag `<base>`
  de las páginas que se están sirviendo.
- child-src: especifica el listado de URLs que pueden ser definidas
  dentro de un frame hijo. Esta versión reemplaza el uso de la
  antigua opción `frame-src` (actualmente deprecada).
- connect-src: define los orígenes válidos para realizar conexiones
  desde la página (via XHR, WebSockets y EventSource).
- font-src: especifica los orígenes válidos desde donde la página
  puede obtener fuentes.
- form-action: lista los endpoints válidos hacia donde la página
  puede realizar envío formularios (atributo `action` de un `form`).
- frame-ancestors: especifica los orígenes que pueden embeber la
  página actual (dentro de un `frame`, `iframe`, `embed` o `applet`).
- frame-src: ***deprecado***. Use `child-src` en su lugar.
- img-src: permite especificar los origenes desde los cuales pueden
  ser obtenidas las imagenes en la página.
- media-src: permite restringir los orígenes desde los cuales la
  página puede obtener vídeo y audio.
- object-src: permite especificar los orígenes para objetos de tipo
  flash o plugins java.
- plugin-types: permite limitar el tipo de plugins que una página
  puede invocar.
- report-uri: permite especificar una URL donde el navegador
  enviará reportes respecto a violaciones del CSP configurado. Esto
  es de mucha utilidad durante el desarrollo y pruebas del sistema
  para evitar que vulnerabilidades potenciales lleguen a producción.
- style-src: permite especificar origenes permitidos para hojas de
  estilo CSS.
- upgrade-insecure-requests: indica al navegador que debe reescribir
  las peticiones cambiando HTTP por HTTPS (HTTP sobre SSL/TLS). Esto
  es en caso de sitios con gran cantidad de páginas por mantener o
  modificar.

> NOTA: Más información respecto de la CSP puede ser encontrada en
el [siguiente enlace](https://www.html5rocks.com/en/tutorials/security/content-security-policy/)
