# AFP Habitat - Convenciones del equipo Nueva Web #

Este repositorio contiene algunas de las convenciones, normas y
buenas prácticas que debemos mantener como equipo para conseguir
el desarrollo de un sistema robusto y estable.

## Introducción al proyecto Nueva Web ##

El proyecto Nueva Web de AFP Habitat tiene como objetivo reemplazar
todo el sitio web privado al que acceden los clientes por una nueva
versión mejorada, utilizando el framework Angular, junto con una
nueva API REST desarrollada utilizando Java y Spring boot desplegada
sobre una plataforma Kubernetes.

El siguiente diagrama presenta la arquitectura general del sistema.
El [siguiente enlace](ARQUITECTURA.md) profundiza en la arquitectura
del sistema.

![Diagrama de arquitectura general](images/diagrama-arq-general.png)

> NOTA: El diagrama considera al core Sysde ya en operación (inicialmente
> los componentes Java Spring boot consumen servicios SOAP desde OSB 11g,
> el cual apunta a los sistemas core actuales).

## Convenciones para contribuir al proyecto ##

Las siguientes son las convenciones del equipo de la Nueva Web
relacionadas con la forma de desarrollar. Si eres nuevo en el equipo
o simplemente si tienes alguna duda revisa las siguientes secciones.

* Recomendaciones de [desarrollo seguro Angular](SEGURIDAD_ANGULAR.md).
* Recomendaciones de [desarrollo seguro Java](SEGURIDAD_JAVA.md).
* Reglas del juego para la [revisión de pares](PEER_REVIEW.md).
* Convenciones de [código fuente Java](CONVENCIONES_JAVA.md).
* Estrategia de [Versionamiento](VERSIONAMIENTO.md)
* Buenas prácticas en registros de Log.

## Información de utilidad ##

El [siguiente documento](UTILIDAD.md) contiene información de utilidad
para cualquier participante de equipo.
