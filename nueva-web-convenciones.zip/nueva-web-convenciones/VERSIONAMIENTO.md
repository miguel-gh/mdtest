# Estrategia de Versionamiento AFP Habitat #

A continuación se presenta a estrategia de versionamiento para los equipos
de desarrollo del proyecto Nueva Web de AFP Habitat.

## Definiciones Globales ##

A continuación se incluyen algunas definiciones globales relacionadas
con el esquema de versionamiento.

1. Gitflow *"Nueva Web"*: Se utilizará en nuestro proceso de desarrollo y
    entregas. Es una estrategia de manejo de ramas basada en Gitflow,
    con leves diferencias.
2. Versionamiento semántico: permitirá marcar las versiones
    de componentes significativamente.
3. Contratos de servicios: se segurián reglas respecto del contrato
    de los servicios que permitan garantizar compatibilidad con
    versiones anteriores.
4. Los componentes se empaquetarán en imágenes docker marcadas con su
    correspondiente versión.
5. Los componentes deben incorporar un archivo CHANGELOG que indique
    los cambios conforme se han liberado.

### Descripción de estrategia Gitflow ###

A continuación se presenta un resumen del funcionamiento de gitflow.
Como notarás, se trata del esquema que ya estamos utilizando en
nuestro desarrollo.

Gitflow consiste en utilizar una estrategia de ramas con
responsabilidades definidas. Es decir:

- `master`: es la rama principal del repositorio. Lo que se
  pasa a producción queda en esta rama sincronizado, y marcado
  con una etiqueta (tag).
- `develop`: es la rama de lo que se está desarrollando en
  un momento determinado.
- `feature/*`: son las ramas sobre las cuales se desarrollan
  las nuevas funcionalidades.
- `release/*`: son las ramas sobre las que se trabaja para
  lanzar una nueva versión release del producto.
- `hotfix/*`: son ramas utilizadas para corregir rápidamente
  defectos detectados en producción.

El siguiente diagrama presenta un resumen del funcionamiento de
la estrategia gitflow.

![Gitflow](images/gitflow.png)

Puede encontrar más información respecto de gitflow en el
[siguiente enlace](https://datasift.github.io/gitflow/IntroducingGitFlow.html).

### Variante Gitflow Nueva Web ###

Con el fin de agilizar las tareas de revisión de pares del equipo de
la nueva web, se aplicará una variación en el esquema gitflow básico.
Esta variante de gitflow ***solo será aplicada*** cuando la característica
a desarrollar pueda ser dividida etapas de desarrollo más pequeñas.

Esta variante requiere la creación de ramas `feature/<nombre>-vNN-<info>` más
pequeñas originadas desde la rama `feature/<nombre>` oficial o principal.

Estas ramas permitirán al desarrollador publicar su código de forma
periódica, a la vez que podrá realizar solicitudes de revisión de pares
parciales, de tamaño pequeño y que sean rápidamente analizables por el resto
del equipo y más fácilmente corregibles.

Una vez que el feature está completamente implementado, se realizará el
PR final contra la rama `develop`. Una vez mezclada, todas las ramas
`feature/*` relacionadas con esta característica deberían ser
eliminadas.

La rama feature principal debe ser sincronizada periódicamente con los
cambios realizados sobre la rama `develop` para reducir el riesgo de
complicaciones en el merge final.

### Versionamiento semántico (Java/Angular) ###

Como se mencionó antes, se seguirán las reglas del
[versionamiento semántico](https://semver.org/lang/es/) con el fin
de marcar las versiones de los componentes. Las principales normas
son las siguientes:

- El formato será `X.Y.Z-[SNAPSHOT|RELEASE]`.
- Un cambio en `X` (major) representa un refactor completo y ruptura
    de compatibilidad con la versión anterior.
- Un cambio en `Y` (minor) representa incorporar o mejorar funcionalidades,
    sin romper compatibilidad con la versión anterior.
- Un cambio en `Z` (patch) representa una corrección a un defecto reportado,
    sin romper compatibilidad con la versión anterior.
- El uso de `SNAPSHOT` indica una versión en desarrollo inestable
    que cambiará constantemente. Por ejemplo `1.0.0-SNAPSHOT`.
- Una versión release del componente se marcará con el uso de la
    palabra `RELEASE` indicando que se trata de una versión estable
    con posibilidad de ser liberada a producción.
- Una vez que un paquete versionado ha sido liberado (RELEASE), los
    contenidos de esa versión NO DEBEN ser modificadas. Cualquier
    modificación DEBE ser procesada como una nueva versión a liberar.
- Preliminarmente el responsable de gestionar la rama `release/*` será el
    arquitecto TINET/HABITAT quien se apoyará en los líderes técnicos
    del equipo de proyecto para realizar la tarea.

### Reglas de respecto de contratos de servicios ###

Una vez liberada la primera versión no será posible seguir haciendo
cambios que puedan afectar el contrato.

- Se mantendrá la version 1 en la URL.
- No debe haber cambios que impacten el contrato.
  - No se cambiaran nombres de parametros o datos de salida.
  - No se cambiarán tipos de dato o formato en parámetros o datos
      de salida.
  - No se cambiará la URL de un servicio publicado.
  - No se cambiará el método HTTP del servicio publicado.
- Es posible incorporar cambios que no rompan el contrato definido.
  - Se pude agregar parámetros, y asumir valores predeterminados para los
      clientes antiguos.
  - Se podrán incorporar valores adicionales en las respuestas.
  - Se pueden incorporar nuevos servicios y nuevos métodos HTTP.

## Consideraciones particulares ##

### Versionamiento de la aplicación Angular ###

- Versión global almacenada en el repositorio del proyecto (`package.json`).
    Cambia cada vez que se crea una rama release modificando alguno de las
    aplicaciones internas.
- Cada aplicación manejará su versión de forma independiente.
- Adicionalmente cada release realizará el registro de los cambios en un
    archivo llamado `CHANGELOG` en la raiz del repositorio.

### Versionamiento de API ###

- Versión principal (major) en la URL (`/api2/v1/nombre_servicio`).
- Incorporar el valor exacto de la versión mediante un nuevo endpoint
    (`GET /version`) expuesto en la raiz del path base del servicio.
- La versión exacta debe ser consistente con la version del servicio
    documentada en swagger.
- Por ejemplo, el path para obtener la versión del componente de login
    es `GET /api2/v1/seguridad/internet/login/version`.

### Versión desplegable durante pruebas funcionales ###

Se habilitará el despliegue de la versión que le sirva a QA para
verificar la versión sobre la que está realizando pruebas. Las siguientes
consideraciones son importantes:

- La versión global del proyecto debe quedar registrada y disponible
    para el equipo de calidad con el fin de evidenciar la versión
    exacta que se está certificando.
- La versión deberá contener la versión oficial del componente que
    se está ejecutando (version asociada a imagen docker).
- Adicionalmente debería incluir la fecha del commit desde el cual se
    realizó el despliegue en formato `yyyy-MM-ddTHH:mm:ss`.
- El marcador de versión debe, además, incluir el hash del commit del
    repositorio GIT desde el cual fue generado, con el fin de facilitar
    acceder al código base.
- Preliminarmente, la versión de cada componente se almacenará, como parte
    de un objeto JSON serializado como `string` en el objeto
    `sessionStorage` bajo el nombre `version-<id-de-la-aplicacion>`. Los
    datos de versión concretos se utilizará como valor dentro del objeto
    JSON serializado.

A continuación se presenta un ejemplo de como se desplegaría la versión
de la aplicación `seguridad-autenticacion-internet-login-login` siguiendo
las definiciones declaradas anteriormente:

![Verisionamiento Angular](images/despliegue-version.png)

## Procedimiento de versionamiento ##

- Usaremos la versión X.Y.Z-SNAPSHOT como versión durante nuestro
    desarrollo (ramas `develop`/`feature`).
- Parar liberar una versión del producto a QA crearemos una rama
    de tipo release candidato con el objetivo de estabilizar la
    entrega.
  - El formato del nombre de la rama es `release/version-X.Y-RC`.
      Por ejemplo: `release/version-1.2-RC`.
  - El primer ajuste dentro de esta rama será ajustar la versión en los
      archivos descriptores con el número de versión de release
      candidato reemplazando el `SNAPSHOT` por `RELEASE`.
      En proyectos de tipo java, se ajusta en los archivos `pom.xml`
      del componente. Para esto se puede utilizar el comando maven
      `mvn versions:set`.
      En el repositorio de aplicaciones front, esto se debe realizar
      manualmente el archivo `package.json`, así como en el archivo
      `deployment-config.lst` para cada una de las aplicaciones que
      se incluirán en el actual release.
  - Toda dependencia utilizada en la versión release de un componente
      debe referenciar sólamente a versiones release previamente
      existentes.
  - Se actualizará el archivo `CHANGELOG.md` para indicar las
      características y correcciones incorporadas en esta versión
      candidata.
  - Cada incidente detectado por el equipo de calidad será corregido
      sobre esta rama `release` y traspasada en forma paralela a la
      rama `develop`. Cada nuevo ajuste sobre esta rama requerirá
      actualizar la versión en los descriptores nuevamente.
  - Una vez estabilizada la aplicación en la rama `release` se
      procederá a realizar el Pull-Request contra la rama `master`.
      Luego de la mezcla se generará un tag marcando la versión
      aprobada de la aplicación.
- La versión en la rama develop debe incrementarse para iniciar el
    desarrollo de nuevas funcionalidades (nueva versión minor).
  - Para esto también es posible el utilizar el comando maven
    `mvn versions:set`. En el caso del repositorio angular, esta
    tarea se debe realizar manualmente.
  - Sobre la rama develop se seguirán mezclando features adicionales
      una vez que sus desarrollos se completen.

Un ejemplo de invocación al comando `mvn versions:set` es el siguiente:

```bash
% mvn versions:set -DnewVersion=2.50.1-SNAPSHOT
```

### Formato del archivo CHANGELOG ###

Con respecto al archivo `CHANGELOG`, su objetivo es llevar un registro
de los cambios incorporados en cada release realizado hasta la fecha.

El formato está basado en [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),

Los datos que es importante considerar dentro del registro de cambios
son los siguientes:

- Version liberada: Versión exacta del componente que está siendo liberado.
- Fecha Entrega: fecha en la que se generó la rama release en cuestión.
- Features Entregados: Corta descripcion de la(s) caracteristica(s)
    agregadas o modificadas en el release.
- Defectos corregidos: Listado de defectos que se corrigen en esta versión
    liberada del componente (indicando el código de issue tracker).

Adicionalmente, considerando el caso particular de la aplicación angular
se deberá considerar lo siguiente:

- Versiones de los componentes incorporados o modificados en la versión
    que se está liberando.
- Por cada componente modificado, agregar breve descripcion del cambio
- Versión de los servicios que soportan a la aplicación angular
    (listado de servicios con sus respectivas versiones).
