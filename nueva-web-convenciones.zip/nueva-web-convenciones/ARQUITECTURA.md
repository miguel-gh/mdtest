# AFP Habitat - Arquitectura Nueva Web #

La arquitectura general del proyecto Nueva Web consiste en múltiples
aplicaciones tipo SPA (Single Page Applitacion) desarrolladas usando el
framework Angular 9 que consumen servicios REST construidos utilizando
lenguaje Java y el framework Spring Boot 2.

Desde el punto de vista del despliegue, los componentes angular se instalarán
sobre el servidor Web NGiNX, mientras que los componentes java se desplegarán
como contenedores docker sobre una nueva plataforma Kubernetes.

## Definiciones técnicas importantes ##

Para tener más antecedentes del proyecto te invito a revisar los siguientes
documentos de utilidad:

1. [Presentación de introducción](https://docs.google.com/presentation/d/1_gYZ8a1BrHIfFD9T738rnzuhn_DNGoMx2i1RzhsHOF4/edit?usp=sharing)
    al proyecto.
2. [Documento de Arquitectura](https://docs.google.com/document/d/1hNfgZuzw3YT1baKeWlDGYUlN4Be2IAMFGqFpHdSY9WQ/edit?usp=sharing)
    de la Nueva Web.

### Esquema de Seguridad ###

Desde el punto de vista de la seguridad, se utilizará el estandar
OIDC/OAuth 2.0 para proteger los recursos que disponibilizará el sistema.

Uno de los desafíos a resolver corresponde a la posibilidad de soportar la
convivencia temporal de la nueva Web Angular con aplicaciones web
tradicionales desplegadas actualmente en la plataforma Weblogic Server.

El esquema de seguridad general, considerando también el soporte de la
convivencia Angular/Weblogic se presenta en el siguiente diagrama.

![Diagrama Seguridad OIDC/OAuth 2.0](images/diagrama-arq-seguridad.png)

De acuerdo a la definición de OIDC/OAuth 2.0, existen 3 roles que son
necesarios dentro del esquema de seguridad:

1. Cliente. Corresponde a la aplicación cliente que pretende acceder a los
    recursos de los cuales el usuario es dueño, en nombre del usuario.
    En nuestro caso la aplicación cliente es la aplicación Angular. Otro
    cliente OAuth 2.0 podría ser, en el futuro, la aplicación móvil.
2. Servidor de autorización. Corresponde al servidor que administra el
    acceso a los recursos a través de la generación de tokens. El usuario
    se autentica y autoriza el acceso a dichos recursos a través de este
    componente. En nuestro caso el servidor OAuth 2.0 es un desarrollo Java
    que utiliza el framework Spring basado en el proyecto
    [MITREid Connect](https://github.com/mitreid-connect/OpenID-Connect-Java-Spring-Server),
    personalizando la autenticación de los usuarios invocando a servicios
    backend de AFP Habitat.
3. Servidor de recursos. Corresponde al servidor que proporciona los recursos
    pertenecientes al usuario y a los cuales la aplicación ciente solicita
    acceder en nombre del usuario. En nuestro caso el servidor de recursos
    corresponde a los servicios de la API REST.

## Enlaces de utilidad ##

A continuación se describen algunos enlaces con información de utilidad con
relación a la arquitectura del sistema y seguridad.

- Framework [Angular 9](https://angular.io/docs).
- Framework [Spring boot 2](https://spring.io/projects/spring-boot).
- Herramienta de desarrollo [front monorepo NX](https://nx.dev/angular).
- Diagramas de [flujos OAuth 2.0](https://medium.com/@darutk/diagrams-and-movies-of-all-the-oauth-2-0-flows-194f3c3ade85).
    En nuestro caso se utilizará el flujo "Resource Owner Password Credentials Flow".
- Revisión de [contenido de tokens JWT](https://jwt.io/).
- Repositorio bitbucket del [Servidor de Autorizacion](https://bitbucket.org/Tinet/afp-habitat-oauth2-oidc-server-impl/src/master/).
- Repositorio bitbucket del [Gateway de sesión en WLS](https://bitbucket.org/Tinet/nueva-web-jaas-gateway/src/master/).
- Repositorio bitbucket del [Auth provider en WLS](https://bitbucket.org/Tinet/nueva-web-jaas-auth-provider/src/master/).
